﻿namespace ABCRetail.Models
{
    public class OrderMessage
    {
        public string CustomerId { get; set; } = string.Empty;   
        public string CustomerName { get; set; } = string.Empty;
        public string ProductId { get; set; } = string.Empty;    
        public string ProductName { get; set; } = string.Empty;
        public int Quantity { get; set; }
        public double UnitPrice { get; set; }
        public double TotalAmount { get; set; }
        public string StatusDescription { get; set; } = string.Empty;
        public DateTime OrderDate { get; set; } = DateTime.Now;
        public string Status { get; set; } = "Pending"; // Pending, Processing, Completed, Cancelled
        public string? Notes { get; set; }
    }
}
