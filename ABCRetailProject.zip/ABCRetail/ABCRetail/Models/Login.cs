﻿using System.ComponentModel.DataAnnotations;

namespace ABCRetail.Models
{
    public class Login
    {
        public string username { get; set; } = string.Empty;
        public string password { get; set; } = string.Empty;
        public string role { get; set; } = string.Empty;
    }
}
