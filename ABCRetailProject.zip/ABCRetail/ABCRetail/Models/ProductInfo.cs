﻿using Azure;
using Azure.Data.Tables;

namespace ABCRetail.Models
{
    public class ProductInfo : ITableEntity
    {
        public string PartitionKey { get; set; } = "PRODUCT";
        public string RowKey { get; set; } = Guid.NewGuid().ToString();
        public required string ProductName { get; set; }
        public required string Description { get; set; }
        public double Price { get; set; }
        public string? ImageUrl { get; set; }  // Made optional since it's populated after blob upload
        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }
    }
}
