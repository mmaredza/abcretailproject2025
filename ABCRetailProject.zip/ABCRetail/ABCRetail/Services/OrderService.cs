﻿using ABCRetail.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Dapper;

namespace ABCRetail.Services
{
    public class OrderService
    {
        private readonly string _connectionString;

        public OrderService(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task AddOrderAsync(OrderMessage order)
        {
            using var connection = new SqlConnection(_connectionString);
            await connection.ExecuteAsync(@"
                INSERT INTO Orders (CustomerId, CustomerName, ProductId, ProductName, Quantity, UnitPrice, TotalAmount, StatusDescription, Status, OrderDate, Notes)
                VALUES (@CustomerId, @CustomerName, @ProductId, @ProductName, @Quantity, @UnitPrice, @TotalAmount, @StatusDescription, @Status, @OrderDate, @Notes)
            ", order);
        }

        public async Task<List<OrderMessage>> GetOrdersByCustomerIdAsync(string customerId)
        {
            using var connection = new SqlConnection(_connectionString);
            var orders = await connection.QueryAsync<OrderMessage>(
                "SELECT * FROM Orders WHERE CustomerId = @CustomerId", new { CustomerId = customerId });
            return orders.AsList();
        }

        public async Task<List<OrderMessage>> GetAllOrdersAsync()
        {
            using var connection = new SqlConnection(_connectionString);
            var orders = await connection.QueryAsync<OrderMessage>("SELECT * FROM Orders");
            return orders.AsList();
        }

        public async Task UpdateOrderStatusAsync(int orderId, string status)
        {
            using var connection = new SqlConnection(_connectionString);
            await connection.ExecuteAsync("UPDATE Orders SET Status = @Status WHERE Id = @OrderId", new { Status = status, OrderId = orderId });
        }
    }
}
