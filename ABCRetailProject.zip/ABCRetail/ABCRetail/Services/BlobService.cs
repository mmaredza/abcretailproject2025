﻿using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Http;
//(IIEVC, 2024),
//(MicrosoftLearn, 2024),
//(Vatsa, n.d.)

namespace ABCRetail.Services //(Marczak, 2020)
{
    public class BlobService //(Marczak, 2020)
    {
        private readonly BlobServiceClient _blobServiceClient; //(Marczek, 2019)

        public BlobService(BlobServiceClient blobServiceClient)
        {
            _blobServiceClient = blobServiceClient;
        }

        public BlobContainerClient GetContainer(string containerName)
        {
            return _blobServiceClient.GetBlobContainerClient(containerName);
        }

        public async Task<string> UploadAsync(IFormFile file, string containerName)
        {
            try
            {
                var containerClient = _blobServiceClient.GetBlobContainerClient(containerName);
                await containerClient.CreateIfNotExistsAsync();

                string blobName = $"{Guid.NewGuid()}-{file.FileName}";
                var blobClient = containerClient.GetBlobClient(blobName);

                using var stream = file.OpenReadStream();
                await blobClient.UploadAsync(stream, true);

                return blobClient.Uri.ToString();
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to upload image: {ex.Message}", ex);
            }
        }
    }
}
