﻿using Azure.Storage.Queues;
using Azure.Storage.Queues.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;

namespace ABCRetail.Services //(Marczek, 2019)
{
    public class QueueService //(Marczak, 2020)
    {
        private readonly QueueClient _queueClient;

        public QueueService(QueueServiceClient queueServiceClient, IConfiguration config)
        {
            var queueName = config["AzureStorage:QueueName"] ?? "orders";
            _queueClient = queueServiceClient.GetQueueClient(queueName);
            _queueClient.CreateIfNotExists();
        }

        public async Task EnqueueMessageAsync<T>(T payload)
        {
            string jsonMessage = JsonSerializer.Serialize(payload);
            await _queueClient.SendMessageAsync(jsonMessage);
        }

        public async Task EnqueueMessageAsync(string message)
        {
            await _queueClient.SendMessageAsync(message);
        }


        public async Task<IEnumerable<QueueMessage>> GetAllMessagesAsync(int maxMessages = 32)
        {
            var visibilityTimeout = TimeSpan.FromSeconds(1); 
            var messages = await _queueClient.ReceiveMessagesAsync(maxMessages, visibilityTimeout);
            return messages.Value;
        }

        // Peek messages without consuming them - useful for viewing all orders
        public async Task<IEnumerable<PeekedMessage>> PeekAllMessagesAsync(int maxMessages = 32)
        {
            var messages = await _queueClient.PeekMessagesAsync(maxMessages);
            return messages.Value;
        }

        // Deletes a message by ID and popReceipt.
        public async Task DeleteMessageAsync(string messageId, string? popReceipt = null)
        {
            if (popReceipt == null)
            {
                var messages = await _queueClient.ReceiveMessagesAsync(1);
                if (messages.Value.Length == 0)
                    return;

                var message = messages.Value[0];
                messageId = message.MessageId;
                popReceipt = message.PopReceipt;
            }

            await _queueClient.DeleteMessageAsync(messageId, popReceipt);
        }
    }
}
