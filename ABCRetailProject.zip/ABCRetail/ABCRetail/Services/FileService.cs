﻿using Azure.Storage.Files.Shares;
using Azure.Storage.Files.Shares.Models;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace ABCRetail.Services //(Marczek, 2019)
{
    public class FileService //(Marczak, 2020)
    {
        private readonly ShareClient _shareClient;

        public FileService(ShareServiceClient shareServiceClient, IConfiguration config) //(MicrosoftLearn, 2025)
        {
            var shareName = config["AzureStorage:FileShareName"] ?? "contracts";
            _shareClient = shareServiceClient.GetShareClient(shareName);
            _shareClient.CreateIfNotExists();
        }

        public async Task UploadFileAsync(string fileName, Stream fileStream)
        {
            var root = _shareClient.GetRootDirectoryClient();
            var fileClient = root.GetFileClient(fileName);
            await fileClient.CreateAsync(fileStream.Length);
            await fileClient.UploadRangeAsync(new Azure.HttpRange(0, fileStream.Length), fileStream);
        }

        public async Task<IEnumerable<string>> GetAllFilesAsync()
        {
            var root = _shareClient.GetRootDirectoryClient();
            var files = new List<string>();

            await foreach (ShareFileItem item in root.GetFilesAndDirectoriesAsync())
            {
                if (!item.IsDirectory)
                    files.Add(item.Name);
            }

            return files;
        }

        public async Task<Stream?> DownloadFileAsync(string fileName)
        {
            var root = _shareClient.GetRootDirectoryClient();
            var fileClient = root.GetFileClient(fileName);

            if (!await fileClient.ExistsAsync())
                return null;

            var memoryStream = new MemoryStream();
            ShareFileDownloadInfo download = await fileClient.DownloadAsync();
            await download.Content.CopyToAsync(memoryStream);
            memoryStream.Position = 0;
            return memoryStream;
        }

        public async Task DeleteFileAsync(string fileName)
        {
            var root = _shareClient.GetRootDirectoryClient();
            var fileClient = root.GetFileClient(fileName);
            await fileClient.DeleteIfExistsAsync();
        }
    }
}
