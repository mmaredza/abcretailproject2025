using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Dapper;
using ABCRetail.Models;

namespace ABCRetail.Services
{
    public class LoginSqlService
    {
        private readonly string _connectionString;

        public LoginSqlService(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("DefaultConnection") ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
        }

        public async Task<Login?> AuthenticateAsync(string username, string password)
        {
            string query = @"SELECT * FROM logins 
                             WHERE username = @username AND password = @password";

            using var connection = new SqlConnection(_connectionString);
            return await connection.QueryFirstOrDefaultAsync<Login>(query, new { username, password });
        }
    }
}


