﻿using ABCRetail.Models;
using Azure;
using Azure.Data.Tables;
using Microsoft.Extensions.Configuration;

namespace ABCRetail.Services
{
    public class TableService
    {
        private readonly TableServiceClient _tableServiceClient;
        private readonly string _customerTableName;
        private readonly string _productTableName;
        private readonly string _orderTableName;

        public TableService(TableServiceClient tableServiceClient, IConfiguration config)
        {
            _tableServiceClient = tableServiceClient;
            _customerTableName = config["AzureStorage:CustomerTableName"] ?? "customers";
            _productTableName = config["AzureStorage:ProductTableName"] ?? "products";
            _orderTableName = config["AzureStorage:OrderTableName"] ?? "orders";
        }

        private TableClient GetTableClient(string tableName)
        {
            var tableClient = _tableServiceClient.GetTableClient(tableName);
            tableClient.CreateIfNotExists();
            return tableClient;
        }

        // Customer operations
        public async Task AddCustomerAsync(CustomerProfiles customer)
        {
            customer.PartitionKey ??= "CUSTOMER";
            customer.RowKey ??= Guid.NewGuid().ToString();
            await GetTableClient(_customerTableName).AddEntityAsync(customer);
        }

        public async Task<IEnumerable<CustomerProfiles>> GetAllCustomersAsync()
        {
            return GetTableClient(_customerTableName)
                   .Query<CustomerProfiles>(c => c.PartitionKey == "CUSTOMER")
                   .ToList();
        }

        public async Task<CustomerProfiles?> GetCustomerByRowKeyAsync(string rowKey)
        {
            try
            {
                var response = await GetTableClient(_customerTableName).GetEntityAsync<CustomerProfiles>("CUSTOMER", rowKey);
                return response.Value;
            }
            catch (RequestFailedException)
            {
                return null;
            }
        }

        // NEW: Get customer by last name (used for login username)
        public async Task<string?> GetCustomerFirstNameByLastNameAsync(string lastName)
        {
            if (string.IsNullOrEmpty(lastName)) return null;
            var tableClient = GetTableClient(_customerTableName);
            var customer = tableClient.Query<CustomerProfiles>(c => c.PartitionKey == "CUSTOMER" && c.LastName == lastName)
                                      .FirstOrDefault();
            return customer?.FirstName;
        }


        public async Task<CustomerProfiles?> GetCustomerByLastNameAsync(string lastName)
        {
            if (string.IsNullOrEmpty(lastName))
                return null;

            var tableClient = GetTableClient(_customerTableName);
            var customers = tableClient.Query<CustomerProfiles>(
                c => c.PartitionKey == "CUSTOMER" && c.LastName == lastName
            );
            return customers.FirstOrDefault();
        }
        public async Task UpdateCustomerAsync(CustomerProfiles customer)
        {
            await GetTableClient(_customerTableName).UpdateEntityAsync(customer, customer.ETag, TableUpdateMode.Replace);
        }

        public async Task DeleteCustomerAsync(string rowKey)
        {
            await GetTableClient(_customerTableName).DeleteEntityAsync("CUSTOMER", rowKey);
        }

        // Product operations
        public async Task AddProductAsync(ProductInfo product)
        {
            product.PartitionKey ??= "PRODUCT";
            product.RowKey ??= Guid.NewGuid().ToString();
            await GetTableClient(_productTableName).AddEntityAsync(product);
        }

        public async Task<IEnumerable<ProductInfo>> GetAllProductsAsync()
        {
            return GetTableClient(_productTableName)
                   .Query<ProductInfo>(p => p.PartitionKey == "PRODUCT")
                   .ToList();
        }

        public async Task<ProductInfo?> GetProductByRowKeyAsync(string rowKey)
        {
            try
            {
                var response = await GetTableClient(_productTableName).GetEntityAsync<ProductInfo>("PRODUCT", rowKey);
                return response.Value;
            }
            catch (RequestFailedException)
            {
                return null;
            }
        }

        public async Task UpdateProductAsync(ProductInfo product)
        {
            await GetTableClient(_productTableName).UpdateEntityAsync(product, product.ETag, TableUpdateMode.Replace);
        }

        public async Task DeleteProductAsync(string rowKey)
        {
            await GetTableClient(_productTableName).DeleteEntityAsync("PRODUCT", rowKey);
        }
    }
}
