using ABCRetail.Services;
using Azure.Data.Tables;
using Azure.Storage.Blobs;
using Azure.Storage.Queues;
using Azure.Storage.Files.Shares;
using System.Globalization;

var builder = WebApplication.CreateBuilder(args);

// Configure culture for proper decimal parsing
CultureInfo.DefaultThreadCurrentCulture = new CultureInfo("en-US");
CultureInfo.DefaultThreadCurrentUICulture = new CultureInfo("en-US");

// Add services to the container
builder.Services.AddControllersWithViews();

// Add session support
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

// Register Azure Storage Clients
builder.Services.AddSingleton(sp =>
    new TableServiceClient(builder.Configuration["AzureStorage:ConnectionString"]));

builder.Services.AddSingleton(sp =>
    new BlobServiceClient(builder.Configuration["AzureStorage:ConnectionString"]));

builder.Services.AddSingleton(sp =>
    new QueueServiceClient(builder.Configuration["AzureStorage:ConnectionString"]));

builder.Services.AddSingleton(sp =>
    new ShareServiceClient(builder.Configuration["AzureStorage:ConnectionString"]));

// Register custom services
builder.Services.AddSingleton<TableService>();
builder.Services.AddSingleton<BlobService>();
builder.Services.AddSingleton<QueueService>();
builder.Services.AddSingleton<FileService>();

// Register SQL login service
builder.Services.AddSingleton<LoginSqlService>();

var app = builder.Build();

// Configure the HTTP request pipeline
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseSession();

app.UseAuthorization();

// Default route
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Welcome}/{id?}");

app.Run();



//REFERENCES:
/*Ayo, F., 2024. How to add an Entity to Azure Table Storage from Visual Studio using .NET 6/7/8 LTS. [Online] 
Available at: https://www.youtube.com/watch?v=0GE8WjyWsE4
[Accessed 23 August 2025].*/

/*GeneXus, n.d. HowTo: Configure Session State In ASP.NET Core [Online]
Available at: https://docs.genexus.com/en/wiki?50626,HowTo%3A+Configure+Session+State+In+ASP.NET+Core
[Accessed 10 November 2025].*/

/*IIEVC, 2024. All about the blob storage - CLDV6211. [Online] 
Available at: https://www.youtube.com/watch?v=tCROBkSoi3Y&list=PL480DYS-b_kevhFsiTpPIB2RzhKPig4iK&index=9
[Accessed 25 August 2025].*/

/*Marczak, A., 2020. AZ-900 Episode 11 | Azure Storage Services | Blob, Queue, Table, Files, Disk and Storage Tiers. [Online] 
Available at: https://www.youtube.com/watch?v=_Qlkvd4ZQuo
[Accessed 22 August 2025].*/

/*Marczek, A., 2019. Azure Storage Tutorial | Introduction to Blob, Queue, Table & File Share. [Online] 
Available at: https://www.youtube.com/watch?v=UzTtastcBsk
[Accessed 23 August 2025].*/

/*MicrosoftLearn, 2024. Quickstart: Azure Blob Storage client library for .NET. [Online] 
Available at: https://learn.microsoft.com/en-us/azure/storage/blobs/storage-quickstart-blobs-dotnet?tabs=visual-studio%2Cconnection-string%2Croles-azure-portal%2Csign-in-azure-cli%2Cidentity-visual-studio&pivots=blob-storage-quickstart-scratch
[Accessed 25 August 2025].*/

/*MicrosoftLearn, 2025. Adding Azure Storage by using Visual Studio Connected Services. [Online] 
Available at: https://learn.microsoft.com/en-us/visualstudio/azure/vs-azure-tools-connected-services-storage?view=vs-2022
[Accessed 23 August 2025].*/

/*MicrosoftLearn, 2025. Azure Tables client library for .NET - version 12.11.0. [Online] 
Available at: https://learn.microsoft.com/en-us/dotnet/api/overview/azure/data.tables-readme?view=azure-dotnet
[Accessed 23 August 2025].*/

/* Microsoft Learn, n.d. Introduction to Azure Storage [Online]
Available at: https://learn.microsoft.com/en-us/azure/storage/common/storage-introduction
[Accessed 10 November 2025].*/

/*Microsoft Learn , n.d. Session and state management in ASP.NET Core. [Online]
 Available at: https://learn.microsoft.com/en-us/aspnet/core/fundamentals/app-state?view=aspnetcore-9.0
[Accessed 10 November 2025].*/


/*MicrosoftLearn, n.d. TableEntity.ETag Property. [Online] 
Available at: https://learn.microsoft.com/en-us/dotnet/api/azure.data.tables.tableentity.etag?view=azure-dotnet
[Accessed 23 August 2025].*/

/*MicrosoftLearn, n.d. TableEntity.RowKey Property. [Online] 
Available at: https://learn.microsoft.com/en-us/dotnet/api/azure.data.tables.tableentity.rowkey?view=azure-dotnet
[Accessed 23 August 2025].*/

/*Vatsa, A. K., n.d. Working With Azure BLOB Storage in MVC. [Online] 
Available at: https://www.c-sharpcorner.com/UploadFile/abhikumarvatsa/working-with-azure-blob-storage-in-mvc/
[Accessed 25 August 2025].*/

