﻿using ABCRetail.Models;
using ABCRetail.Services;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace ABCRetail.Controllers
{
    public class OrderController : Controller
    {
        private const string CART_KEY = "UserCart";
        private readonly TableService _tableService;
        private readonly QueueService _queueService;

        public OrderController(TableService tableService, QueueService queueService)
        {
            _tableService = tableService;
            _queueService = queueService;
        }

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            ViewBag.Customers = await _tableService.GetAllCustomersAsync();
            ViewBag.Products = await _tableService.GetAllProductsAsync();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(OrderMessage order)
        {
            // Validate order and fetch customer/product
            var nameParts = order.CustomerName?.Trim().Split(' ') ?? new string[0];
            if (nameParts.Length < 2)
            {
                ModelState.AddModelError("", "Please select a customer.");
                ViewBag.Customers = await _tableService.GetAllCustomersAsync();
                ViewBag.Products = await _tableService.GetAllProductsAsync();
                return View(order);
            }

            var lastName = nameParts[^1];
            var customer = await _tableService.GetCustomerByLastNameAsync(lastName);
            var product = await _tableService.GetProductByRowKeyAsync(order.ProductId);
            if (customer == null || product == null)
            {
                ModelState.AddModelError("", "Customer or product not found.");
                ViewBag.Customers = await _tableService.GetAllCustomersAsync();
                ViewBag.Products = await _tableService.GetAllProductsAsync();
                return View(order);
            }

            // Add to cart
            order.CustomerName = $"{customer.FirstName} {customer.LastName}";
            order.ProductName = product.ProductName;
            order.UnitPrice = product.Price;
            order.TotalAmount = product.Price * order.Quantity;
            order.Status = "In Cart";
            order.StatusDescription = $"In cart: {order.ProductName} x{order.Quantity}";

            string? cartJson = HttpContext.Session.GetString(CART_KEY);
            var cart = !string.IsNullOrEmpty(cartJson) ? JsonSerializer.Deserialize<List<OrderMessage>>(cartJson) ?? new List<OrderMessage>() : new List<OrderMessage>();
            cart.Add(order);
            HttpContext.Session.SetString(CART_KEY, JsonSerializer.Serialize(cart));

            return RedirectToAction("Cart");
        }

        [HttpGet]
        public IActionResult Cart()
        {
            string? cartJson = HttpContext.Session.GetString(CART_KEY);
            var cart = !string.IsNullOrEmpty(cartJson) ? JsonSerializer.Deserialize<List<OrderMessage>>(cartJson) ?? new List<OrderMessage>() : new List<OrderMessage>();
            return View(cart);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SubmitCart()
        {
            string? cartJson = HttpContext.Session.GetString(CART_KEY);
            var cart = !string.IsNullOrEmpty(cartJson) ? JsonSerializer.Deserialize<List<OrderMessage>>(cartJson) ?? new List<OrderMessage>() : new List<OrderMessage>();

            foreach (var item in cart)
            {
                item.Status = "Submitted";
                item.StatusDescription = $"Order submitted for {item.ProductName} (Qty: {item.Quantity})";
                await _queueService.EnqueueMessageAsync(item);
            }

            HttpContext.Session.Remove(CART_KEY);
            TempData["SuccessMessage"] = "Order submitted successfully.";
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            // Use PeekAllMessagesAsync to view messages without consuming them
            // This ensures all users can see all messages in the queue
            var queueMessages = await _queueService.PeekAllMessagesAsync();
            var orders = new List<OrderMessage>();

            foreach (var msg in queueMessages)
            {
                try
                {
                    var order = JsonSerializer.Deserialize<OrderMessage>(msg.MessageText);
                    if (order != null) orders.Add(order);
                }
                catch { }
            }

            var role = HttpContext.Session.GetString("Role");
            var username = HttpContext.Session.GetString("Username");

            // Admin sees all orders from all customers
            // Customer sees only their own orders
            if (role == "Customer" && !string.IsNullOrEmpty(username))
            {
                orders = orders.Where(o => o.CustomerName?.Split(' ').Last() == username).ToList();
            }
            // If role is Admin or null/empty, show all orders (no filtering)

            return View(orders);
        }
    }
}
