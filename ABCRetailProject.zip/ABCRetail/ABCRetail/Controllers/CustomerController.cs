﻿using System;
using System.Threading.Tasks;
using ABCRetail.Models;
using ABCRetail.Services;
using Microsoft.AspNetCore.Mvc;

namespace ABCRetail.Controllers //(Marczak, 2020)
{
    public class CustomerController : Controller //(Marczek, 2019)
    {
        private readonly TableService _tableService;

        public CustomerController(TableService tableService)
        {
            _tableService = tableService ?? throw new ArgumentNullException(nameof(tableService));
        }

        // GET: Customer
        public async Task<IActionResult> Index()
        {
            var customers = await _tableService.GetAllCustomersAsync();
            return View(customers);
        }

        // GET: Customer/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Customer/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CustomerProfiles customer)
        {
            if (ModelState.IsValid)
            {
                await _tableService.AddCustomerAsync(customer);
                TempData["SuccessMessage"] = "Customer added successfully!";
                return RedirectToAction(nameof(Index));
            }
            return View(customer);
        }

        // GET: Customer/Edit/{rowKey}
        public async Task<IActionResult> Edit(string rowKey)
        {
            var customer = await _tableService.GetCustomerByRowKeyAsync(rowKey);
            if (customer == null)
                return NotFound();

            return View(customer);
        }

        // POST: Customer/Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(CustomerProfiles customer)
        {
            if (ModelState.IsValid)
            {
                await _tableService.UpdateCustomerAsync(customer);
                TempData["SuccessMessage"] = "Customer updated successfully!";
                return RedirectToAction(nameof(Index));
            }
            return View(customer);
        }

        // GET: Customer/Delete/{rowKey}
        public async Task<IActionResult> Delete(string rowKey)
        {
            var customer = await _tableService.GetCustomerByRowKeyAsync(rowKey);
            if (customer == null)
                return NotFound();

            return View(customer);
        }

        // POST: Customer/DeleteConfirmed
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string rowKey)
        {
            await _tableService.DeleteCustomerAsync(rowKey);
            TempData["SuccessMessage"] = "Customer deleted successfully!";
            return RedirectToAction(nameof(Index));
        }

        // DETAILS: Show customer details
        public async Task<IActionResult> Details(string rowKey)
        {
            var customer = await _tableService.GetCustomerByRowKeyAsync(rowKey);
            if (customer == null)
                return NotFound();

            return View(customer);
        }
    }
}
