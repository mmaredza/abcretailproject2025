using Microsoft.AspNetCore.Mvc;
using ABCRetail.Models;
using ABCRetail.Services;
using System.Diagnostics;

namespace ABCRetail.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public async Task<IActionResult> Index([FromServices] TableService tableService,
                                           [FromServices] QueueService queueService,
                                           [FromServices] FileService fileService)
    {
        var customers = await tableService.GetAllCustomersAsync();
        var products = await tableService.GetAllProductsAsync();
        var orders = await queueService.GetAllMessagesAsync();
        var contracts = await fileService.GetAllFilesAsync();

        ViewBag.CustomerCount = customers.Count();
        ViewBag.ProductCount = products.Count();
        ViewBag.OrderCount = orders.Count();
        ViewBag.ContractCount = contracts.Count();

        return View();
    }

    public IActionResult Welcome() => View();

    public IActionResult About()
    {
        ViewData["Message"] = "ABC Retail Online Management System";
        return View();
    }

    public IActionResult Dashboard() => View();

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error() => View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
}
