﻿using ABCRetail.Models;
using ABCRetail.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using System;

namespace ABCRetail.Controllers //(Marczak, 2020)
{ //(IIEVC, 2024),
  //(MicrosoftLearn, 2024),
  //(Vatsa, n.d.)
    public class ProductController : Controller //(Marczek, 2019)
    {
        private readonly TableService _tableService;
        private readonly BlobService _blobService;

        public ProductController(TableService tableService, BlobService blobService)
        {
            _tableService = tableService;
            _blobService = blobService;
        }

        // Lists all products
        public async Task<IActionResult> Index()
        {
            var products = await _tableService.GetAllProductsAsync();
            
            return View(products);
        }

        // CREATE: Show form
        public IActionResult Create() => View();

        // CREATE: Handle submission
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ProductInfo model, IFormFile ImageFile)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            if (ImageFile == null || ImageFile.Length == 0)
            {
                return View(model);
            }

            try
            {
                model.ImageUrl = await _blobService.UploadAsync(ImageFile, "image");
                await _tableService.AddProductAsync(model);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View(model);
            }
        }

        // EDIT: Show form
        public async Task<IActionResult> Edit(string rowKey)
        {
            var product = await _tableService.GetProductByRowKeyAsync(rowKey);
            if (product == null) return NotFound();
            return View(product);
        }

        // EDIT: Handle submission
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(ProductInfo model, IFormFile ImageFile)
        {
            if (!ModelState.IsValid) return View(model);

            var originalProduct = await _tableService.GetProductByRowKeyAsync(model.RowKey);
            if (originalProduct == null)
            {
                return RedirectToAction(nameof(Index));
            }

            model.ETag = originalProduct.ETag;
            model.PartitionKey = originalProduct.PartitionKey;
            model.Timestamp = originalProduct.Timestamp;

            if (ImageFile != null && ImageFile.Length > 0)
            {
                try
                {
                    model.ImageUrl = await _blobService.UploadAsync(ImageFile, "image");
                }
                catch
                {
                    return View(model);
                }
            }
            else
            {
                model.ImageUrl = originalProduct.ImageUrl;
            }

            try
            {
                await _tableService.UpdateProductAsync(model);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View(model);
            }
        }

        // DELETE
        public async Task<IActionResult> Delete(string rowKey)
        {
            var product = await _tableService.GetProductByRowKeyAsync(rowKey);
            if (product == null) return NotFound();
            return View(product);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string rowKey)
        {
            await _tableService.DeleteProductAsync(rowKey);
            return RedirectToAction(nameof(Index));
        }
    }
}
