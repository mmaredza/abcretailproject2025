﻿using ABCRetail.Models;
using ABCRetail.Services;
using Microsoft.AspNetCore.Mvc;

namespace ABCRetail.Controllers
{
    public class LoginController : Controller
    {
        private readonly TableService _tableService;
        private readonly LoginSqlService _loginSqlService;

        public LoginController(TableService tableService, LoginSqlService loginSqlService)
        {
            _tableService = tableService;
            _loginSqlService = loginSqlService;
        }

        [HttpGet]
        public IActionResult Index() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(Login login)
        {
            if (!ModelState.IsValid) return View(login);

            var user = await _loginSqlService.AuthenticateAsync(login.username, login.password);
            if (user != null)
            {
                HttpContext.Session.SetString("Username", user.username);
                HttpContext.Session.SetString("Role", user.role);

                // Get customer's first name
                string? firstName = null;
                if (user.role == "Customer")
                {
                    firstName = await _tableService.GetCustomerFirstNameByLastNameAsync(user.username);
                }
                HttpContext.Session.SetString("FirstName", firstName ?? user.username);

                return user.role == "Admin"
                    ? RedirectToAction("AdminDashboard")
                    : RedirectToAction("CustomerDashboard");
            }

            ViewBag.ErrorMessage = "Invalid username or password.";
            return View(login);
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }

        public IActionResult AdminDashboard()
        {
            ViewBag.Message = $"Welcome, {HttpContext.Session.GetString("FirstName")} (Admin)";
            return View("Dashboard");
        }

        public IActionResult CustomerDashboard()
        {
            ViewBag.Message = $"Welcome, {HttpContext.Session.GetString("FirstName")} (Customer)";
            return View("Dashboard");
        }

        public IActionResult Dashboard()
        {
            var role = HttpContext.Session.GetString("Role");
            if (string.IsNullOrEmpty(role))
            {
                return RedirectToAction("Index");
            }

            return role == "Admin"
                ? RedirectToAction("AdminDashboard")
                : RedirectToAction("CustomerDashboard");
        }
    }
}
