﻿using ABCRetail.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System.IO;

namespace ABCRetail.Controllers //(Marczak, 2020)
{
    public class ContractController : Controller //(Marczek, 2019)
    {
        private readonly FileService _fileService;

        public ContractController(FileService fileService)
        {
            _fileService = fileService;
        }

        // LIST: Show all contract files
        public async Task<IActionResult> Index()
        {
            var files = await _fileService.GetAllFilesAsync();
            return View(files);
        }

        // UPLOAD: Show upload form
        public IActionResult Upload()
        {
            return View();
        }

        // UPLOAD: Handle file submission
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Upload(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                ModelState.AddModelError("", "Please select a file to upload.");
                return View();
            }

            using (var stream = file.OpenReadStream())
            {
                await _fileService.UploadFileAsync(file.FileName, stream);
            }

            TempData["SuccessMessage"] = "Contract uploaded successfully!";
            return RedirectToAction(nameof(Index));
        }

        // DOWNLOAD: Download a contract
        public async Task<IActionResult> Download(string fileName)
        {
            var stream = await _fileService.DownloadFileAsync(fileName);
            if (stream == null)
                return NotFound();

            return File(stream, "application/octet-stream", fileName);
        }

        // DELETE: Delete a contract
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(string fileName)
        {
            await _fileService.DeleteFileAsync(fileName);
            TempData["SuccessMessage"] = "Contract deleted successfully!";
            return RedirectToAction(nameof(Index));
        }
    }
}
